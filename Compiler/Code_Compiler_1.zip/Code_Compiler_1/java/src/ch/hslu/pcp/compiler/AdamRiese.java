package ch.hslu.pcp.compiler;

import java.io.IOException;

public class AdamRiese {

    private int nextchar;

    public boolean isDigit(int c) {
        return c >= '0' && c <= '9';
    }

    public void error() {
        throw new SyntaxException("'" + (char) nextchar + "'");
    }

    public int number() throws IOException {
        int value = nextchar - '0';
        nextchar = System.in.read();
        while (isDigit(nextchar)) {
            value *= 10;
            value += nextchar - '0';
            nextchar = System.in.read();
        }
        return value;
    }

    public int factor() throws IOException {
        int value = 0;
        if (nextchar == '(') {
            nextchar = System.in.read();
            if (nextchar == '(' || isDigit(nextchar)) {
                value = expr();
                if (nextchar != ')') {
                    error();
                }
                nextchar = System.in.read();
            } else {
                error();
            }
        } else {
            value = number();
        }
        return value;
    }

    public int term() throws IOException {
        int value = factor();
        if (nextchar == '*') {
            nextchar = System.in.read();
            if (nextchar == '(' || isDigit(nextchar)) {
                value *= term();
            }
        }
        return value;
    }

    public int expr() throws IOException {
        int value = term();
        if (nextchar == '+') {
            nextchar = System.in.read();
            if (nextchar == '(' || isDigit(nextchar)) {
                value += expr();
            }
        }
        return value;
    }

    public void statement() throws IOException {
        int value = expr();
        if (nextchar != '=') {
            error();
        } else {
            nextchar = System.in.read();
            System.out.println(value);
        }
    }

    public void compute() throws IOException {
        nextchar = System.in.read();
        if (nextchar == '(' || isDigit(nextchar)) {
            statement();
        } else {
            error();
        }
    }
}

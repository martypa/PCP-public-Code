package ch.hslu.pcp.compiler;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DemoAdamRiese {

    public static void main(String[] args) {
        try {
            while (true) {
                System.out.println("Expression: ");
                new AdamRiese().compute();
            }
        } catch (SyntaxException se) {
            System.err.println(se);
        } catch (IOException ex) {
            Logger.getLogger(AdamRiese.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

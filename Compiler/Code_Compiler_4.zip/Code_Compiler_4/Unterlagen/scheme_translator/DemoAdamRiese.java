
import java.io.IOException;
import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

public class DemoAdamRiese {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        boolean trace = false;
        if (args.length > 1) {
            trace = args[1].contains("-trace");
        }
        // create a CharStream that reads from args[0]
        ANTLRInputStream input = new ANTLRInputStream(args[0]);
        // create a lexer that feeds off of input CharStream
        AdamRieseSchemeLexer lexer = new AdamRieseSchemeLexer(input);
        // create a buffer of tokens pulled from the lexer
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        // create a parser that feeds off the tokens buffer
        AdamRieseSchemeParser parser = new AdamRieseSchemeParser(tokens);
        // begin parsing at start rule - stmt
        ParseTree tree = parser.stmt();
        // create standard walker
        ParseTreeWalker walker = new ParseTreeWalker();
        ExtractSchemeListener extractor = new ExtractSchemeListener(trace);
        // initiate walk of tree with listener
        walker.walk(extractor, tree);
        System.out.println(extractor.getSchemeExpr());
    }
}

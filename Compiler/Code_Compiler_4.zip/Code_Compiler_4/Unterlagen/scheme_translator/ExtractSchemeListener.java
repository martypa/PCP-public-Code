/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author zadiehl
 */
public class ExtractSchemeListener extends AdamRieseSchemeBaseListener {

    private boolean trace;
    private String schemeExpr;

    public ExtractSchemeListener(boolean trace) {
        this.trace = trace;
        schemeExpr = "";
    }
    
    @Override
    public void enterAddSubOp(AdamRieseSchemeParser.AddSubOpContext ctx) {
        if (trace) System.out.println("enterAddSubOp");
        schemeExpr = schemeExpr.concat("(" + ctx.op.getText());
    }

    @Override
    public void exitAddSubOp(AdamRieseSchemeParser.AddSubOpContext ctx) {
        if (trace) System.out.println("exitAddSubOp");
        schemeExpr = schemeExpr.concat(")");
    }

    @Override
    public void enterMulDivOp(AdamRieseSchemeParser.MulDivOpContext ctx) {
        if (trace) System.out.println("enterMulDivOp");
        String op = ctx.op.getType() == AdamRieseSchemeParser.DIV ? "/" : ctx.op.getText();
        schemeExpr = schemeExpr.concat("(" + op);
    }

    @Override
    public void exitMulDivOp(AdamRieseSchemeParser.MulDivOpContext ctx) {
        if (trace) System.out.println("exitMulDivOp");
        schemeExpr = schemeExpr.concat(")");
    }

    @Override
    public void enterNumber(AdamRieseSchemeParser.NumberContext ctx) {
        if (trace) System.out.println("enterNumber");
        schemeExpr = schemeExpr.concat(" " + ctx.getText());
    }

    public String getSchemeExpr() {
        return schemeExpr;
    }

}
